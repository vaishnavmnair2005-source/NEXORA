import 'package:flutter/material.dart';
import 'dart:math' as math;
// Ensure this import points to your actual file
import 'auth/role_selection_screen.dart'; 

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _mainController;
  late AnimationController _floatingController;
  late AnimationController _breathingController;

  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();

    // Main animation controller
    _mainController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    // Floating particles animation
    _floatingController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    // Breathing logo animation
    _breathingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    // Fade in animation
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: _mainController,
        curve: Curves.easeIn,
      ),
    );

    // Slide up animation
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _mainController,
        curve: Curves.easeOutCubic,
      ),
    );

    // Start animation
    _mainController.forward();

    // Navigate after delay
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (context, animation, secondaryAnimation) =>
                const RoleSelectionScreen(),
            transitionsBuilder:
                (context, animation, secondaryAnimation, child) {
              return FadeTransition(
                opacity: animation,
                child: child,
              );
            },
            transitionDuration: const Duration(milliseconds: 400),
          ),
        );
      }
    });
  }

  @override
  void dispose() {
    _mainController.dispose();
    _floatingController.dispose();
    _breathingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Define the primary blue color for text/elements since background is white
    const Color primaryBlue = Color(0xFF1565C0); 

    return Scaffold(
      backgroundColor: Colors.white, // <--- CHANGED TO WHITE
      body: Stack(
        children: [
          // Floating particles (Now Blue so they show on white)
          ...List.generate(12, (index) {
            return FloatingParticle(
              animation: _floatingController,
              index: index,
            );
          }),

          // Main content
          Center(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Breathing logo
                    AnimatedBuilder(
                      animation: _breathingController,
                      builder: (context, child) {
                        return Transform.scale(
                          scale: 1.0 + (_breathingController.value * 0.05),
                          child: Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  // Shadow is now blue to contrast with white
                                  color: primaryBlue.withOpacity(
                                    0.2 + (_breathingController.value * 0.2),
                                  ),
                                  blurRadius: 30,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: Image.asset(
                              'assets/logo.png',
                              height: 100,
                            ),
                          ),
                        );
                      },
                    ),

                    const SizedBox(height: 30),

                    // Title: NEXORA (Now Dark Blue)
                    const Text(
                      "NEXORA",
                      style: TextStyle(
                        fontSize: 48,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF0D47A1), // <--- DARK BLUE TEXT
                        letterSpacing: 4.0, 
                      ),
                    ),

                    const SizedBox(height: 8),

                    // --- TAGLINE (Now Grey/Blue) ---
                    Text(
                      "Where Intelligence Meets Humanity",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Colors.blueGrey, // <--- GREY TEXT
                        fontStyle: FontStyle.italic,
                        letterSpacing: 1.2,
                      ),
                    ),

                    const SizedBox(height: 20),

                    // Animated line (Now Blue)
                    AnimatedBuilder(
                      animation: _breathingController,
                      builder: (context, child) {
                        return Container(
                          width: 80 + (_breathingController.value * 20),
                          height: 3,
                          decoration: BoxDecoration(
                            color: primaryBlue.withOpacity(0.5), // <--- BLUE LINE
                            borderRadius: BorderRadius.circular(2),
                          ),
                        );
                      },
                    ),

                    const SizedBox(height: 30),

                    // --- SUBTITLE: BOLD & BLUE GRADIENT ---
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: ShaderMask(
                        shaderCallback: (Rect bounds) {
                          return const LinearGradient(
                            colors: [
                              Color(0xFF0D47A1), // Dark Blue
                              Color(0xFF42A5F5), // Light Blue
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ).createShader(bounds);
                        },
                        blendMode: BlendMode.srcIn,
                        child: const Text(
                          "MediTwin – AI-Powered Digital Twin\nHealthcare System",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 21, 
                            fontWeight: FontWeight.w900, 
                            height: 1.4,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                    // ---------------------------------

                    const SizedBox(height: 50),

                    // Moving dots indicator
                    LoadingDots(animation: _floatingController),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Floating particle widget
class FloatingParticle extends StatelessWidget {
  final Animation<double> animation;
  final int index;

  const FloatingParticle({
    super.key,
    required this.animation,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    final startX = (index * 83 % screenWidth.toInt()).toDouble();
    final startY = (index * 127 % screenHeight.toInt()).toDouble();
    final size = 4.0 + (index % 3) * 2;
    final speed = 0.5 + (index % 3) * 0.3;

    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        final progress = animation.value;
        final yOffset = math.sin(progress * 2 * math.pi + index) * 30 * speed;
        final xOffset = math.cos(progress * 2 * math.pi + index) * 20 * speed;

        return Positioned(
          left: startX + xOffset,
          top: startY + yOffset,
          child: Opacity(
            opacity: 0.3 + (math.sin(progress * 2 * math.pi) * 0.2),
            child: Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                // Changed particle color to Blue so it shows on white bg
                color: Colors.blueAccent.withOpacity(0.6), 
                boxShadow: [
                  BoxShadow(
                    color: Colors.blue.withOpacity(0.3),
                    blurRadius: 4,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// Loading dots indicator
class LoadingDots extends StatelessWidget {
  final Animation<double> animation;

  const LoadingDots({
    super.key,
    required this.animation,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(3, (index) {
            final delay = index * 0.2;
            final progress = (animation.value + delay) % 1.0;
            final scale = 0.7 + (math.sin(progress * 2 * math.pi) * 0.3);

            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 4),
              child: Transform.scale(
                scale: scale,
                child: Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    // Changed dots to Blue
                    color: const Color(0xFF1565C0).withOpacity(0.8),
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }
}