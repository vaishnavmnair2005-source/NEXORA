import 'package:flutter/material.dart';
import 'patient_personal_info_screen.dart';
import '../../utils/constants.dart';
import '../../utils/validators.dart';
import '../../widgets/custom_text_field.dart';
import '../../widgets/gradient_button.dart';
import '../../models/patient_model.dart';

class PatientSignupScreen extends StatefulWidget {
  const PatientSignupScreen({super.key});

  @override
  State<PatientSignupScreen> createState() => _PatientSignupScreenState();
}

class _PatientSignupScreenState extends State<PatientSignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _gmailController = TextEditingController();
  final _deviceNumberController = TextEditingController();
  final _deviceIdController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;

  @override
  void dispose() {
    _gmailController.dispose();
    _deviceNumberController.dispose();
    _deviceIdController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _handleSignup() {
    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true);

      final patient = Patient(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        gmail: _gmailController.text.trim(),
        deviceNumber: _deviceNumberController.text.trim(),
        deviceId: _deviceIdController.text.trim(),
        password: _passwordController.text.trim(),
      );

      Future.delayed(Duration(seconds: 1), () {
        setState(() => _isLoading = false);

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PatientPersonalInfoScreen(patient: patient),
          ),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: AppColors.gradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                    Expanded(
                      child: Text(
                        "Patient Signup",
                        textAlign: TextAlign.center,
                        style: AppTextStyles.heading1,
                      ),
                    ),
                    SizedBox(width: 48),
                  ],
                ),
              ),

              Padding(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    SizedBox(width: 8),
                    Expanded(
                      child: Container(
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.white38,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    SizedBox(width: 8),
                    Expanded(
                      child: Container(
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.white38,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 10),

              Text(
                "Step 1 of 3: Device Information",
                style: TextStyle(color: Colors.white70, fontSize: 14),
              ),

              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(24),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 20),

                        CustomTextField(
                          hint: "Gmail",
                          icon: Icons.email,
                          controller: _gmailController,
                          keyboardType: TextInputType.emailAddress,
                          validator: Validators.validateEmail,
                        ),

                        SizedBox(height: 20),

                        CustomTextField(
                          hint: "Device Number",
                          icon: Icons.devices,
                          controller: _deviceNumberController,
                          validator: Validators.validateDeviceNumber,
                        ),

                        SizedBox(height: 20),

                        CustomTextField(
                          hint: "Device ID",
                          icon: Icons.perm_device_information,
                          controller: _deviceIdController,
                          validator: Validators.validateDeviceId,
                        ),

                        SizedBox(height: 20),

                       CustomTextField(
  hint: "Password",
  icon: Icons.lock,
  controller: _passwordController,
  isPassword: true,
  validator: Validators.validatePassword,
),


                        SizedBox(height: 30),

                        GradientButton(
                          text: "Next",
                          onPressed: _handleSignup,
                          isLoading: _isLoading,
                        ),

                        SizedBox(height: 20),

                        Center(
                          child: TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text(
                              "Already have an account? Login",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}