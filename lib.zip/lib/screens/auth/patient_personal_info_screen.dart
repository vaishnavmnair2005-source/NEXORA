import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'patient_medical_info_screen.dart';
import '../../utils/constants.dart';
import '../../utils/validators.dart';
import '../../widgets/custom_text_field.dart';
import '../../widgets/custom_dropdown.dart';
import '../../widgets/gradient_button.dart';
import '../../models/patient_model.dart';

class PatientPersonalInfoScreen extends StatefulWidget {
  final Patient patient;

  const PatientPersonalInfoScreen({
    super.key,
    required this.patient,
  });

  @override
  State<PatientPersonalInfoScreen> createState() =>
      _PatientPersonalInfoScreenState();
}

class _PatientPersonalInfoScreenState extends State<PatientPersonalInfoScreen> {
  final _formKey = GlobalKey<FormState>();
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _contactController = TextEditingController();
  final _addressController = TextEditingController();

  DateTime? _selectedDate;
  String? _selectedGender;
  bool _isLoading = false;

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _contactController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(2000),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: AppColors.primaryBlue,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _handleNext() {
    if (_formKey.currentState!.validate()) {
      if (_selectedDate == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please select your date of birth'),
            backgroundColor: AppColors.error,
          ),
        );
        return;
      }

      if (_selectedGender == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please select your gender'),
            backgroundColor: AppColors.error,
          ),
        );
        return;
      }

      setState(() => _isLoading = true);

      final updatedPatient = widget.patient.copyWith(
        firstName: _firstNameController.text.trim(),
        lastName: _lastNameController.text.trim(),
        contactNumber: _contactController.text.trim(),
        dateOfBirth: _selectedDate,
        gender: _selectedGender,
        residentialAddress: _addressController.text.trim(),
      );

      Future.delayed(Duration(milliseconds: 500), () {
        setState(() => _isLoading = false);

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                PatientMedicalInfoScreen(patient: updatedPatient),
          ),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: AppColors.gradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                    Expanded(
                      child: Text(
                        "Personal Information",
                        textAlign: TextAlign.center,
                        style: AppTextStyles.heading1.copyWith(fontSize: 22),
                      ),
                    ),
                    SizedBox(width: 48),
                  ],
                ),
              ),

              Padding(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    SizedBox(width: 8),
                    Expanded(
                      child: Container(
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    SizedBox(width: 8),
                    Expanded(
                      child: Container(
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.white38,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 10),

              Text(
                "Step 2 of 3: Personal Details",
                style: TextStyle(color: Colors.white70, fontSize: 14),
              ),

              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(24),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 20),

                        CustomTextField(
                          hint: "First Name",
                          icon: Icons.person,
                          controller: _firstNameController,
                          validator: (value) =>
                              Validators.validateRequired(value, 'First name'),
                        ),

                        SizedBox(height: 20),

                        CustomTextField(
                          hint: "Last Name",
                          icon: Icons.person_outline,
                          controller: _lastNameController,
                          validator: (value) =>
                              Validators.validateRequired(value, 'Last name'),
                        ),

                        SizedBox(height: 20),

                        CustomTextField(
                          hint: "Contact Number",
                          icon: Icons.phone,
                          controller: _contactController,
                          keyboardType: TextInputType.phone,
                          validator: Validators.validatePhone,
                        ),

                        SizedBox(height: 20),

                        InkWell(
                          onTap: () => _selectDate(context),
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.calendar_today,
                                    color: AppColors.primaryBlue),
                                SizedBox(width: 12),
                                Text(
                                  _selectedDate == null
                                      ? 'Date of Birth'
                                      : DateFormat('dd/MM/yyyy')
                                          .format(_selectedDate!),
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: _selectedDate == null
                                        ? Colors.grey
                                        : Colors.black,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        SizedBox(height: 20),

                        CustomDropdown(
                          hint: "Gender",
                          icon: Icons.wc,
                          items: Genders.options,
                          value: _selectedGender,
                          onChanged: (value) {
                            setState(() {
                              _selectedGender = value;
                            });
                          },
                          validator: (value) =>
                              Validators.validateRequired(value, 'Gender'),
                        ),

                        SizedBox(height: 20),

                        CustomTextField(
                          hint: "Residential Address",
                          icon: Icons.home,
                          controller: _addressController,
                          maxLines: 3,
                          validator: (value) => Validators.validateRequired(
                              value, 'Residential address'),
                        ),

                        SizedBox(height: 30),

                        GradientButton(
                          text: "Next",
                          onPressed: _handleNext,
                          isLoading: _isLoading,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}