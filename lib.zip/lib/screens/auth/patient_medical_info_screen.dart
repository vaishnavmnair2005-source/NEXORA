import 'package:flutter/material.dart';
import '../../utils/constants.dart';
import '../../utils/validators.dart';
import '../../widgets/custom_text_field.dart';
import '../../widgets/custom_dropdown.dart';
import '../../widgets/gradient_button.dart';
import '../../models/patient_model.dart';

class PatientMedicalInfoScreen extends StatefulWidget {
  final Patient patient;

  const PatientMedicalInfoScreen({
    super.key,
    required this.patient,
  });

  @override
  State<PatientMedicalInfoScreen> createState() =>
      _PatientMedicalInfoScreenState();
}

class _PatientMedicalInfoScreenState
    extends State<PatientMedicalInfoScreen> {
  final _formKey = GlobalKey<FormState>();
  final _allergiesController = TextEditingController();
  final _medicalHistoryController = TextEditingController();
  final _currentStatusController = TextEditingController();
  final _caregiverNameController = TextEditingController();
  final _caregiverContactController = TextEditingController();

  String? _selectedHospital;
  String? _selectedDoctor;
  String? _selectedBloodGroup;

  bool _isLoading = false;
  bool _showCaregiverSection = false;

  @override
  void dispose() {
    _allergiesController.dispose();
    _medicalHistoryController.dispose();
    _currentStatusController.dispose();
    _caregiverNameController.dispose();
    _caregiverContactController.dispose();
    super.dispose();
  }

  void _handleComplete() {
    if (_formKey.currentState!.validate()) {
      if (_selectedHospital == null ||
          _selectedDoctor == null ||
          _selectedBloodGroup == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please fill all required fields'),
            backgroundColor: AppColors.error,
          ),
        );
        return;
      }

      setState(() => _isLoading = true);

      final completedPatient = widget.patient.copyWith(
        hospital: _selectedHospital,
        doctor: _selectedDoctor,
        bloodGroup: _selectedBloodGroup,
        allergies: _allergiesController.text.trim(),
        medicalHistory: _medicalHistoryController.text.trim(),
        currentStatus: _currentStatusController.text.trim(),
        caregiverName: _caregiverNameController.text.trim().isEmpty
            ? null
            : _caregiverNameController.text.trim(),
        caregiverContact: _caregiverContactController.text.trim().isEmpty
            ? null
            : _caregiverContactController.text.trim(),
      );

      Future.delayed(Duration(seconds: 1), () {
        setState(() => _isLoading = false);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Registration successful!'),
            backgroundColor: AppColors.success,
          ),
        );

        Navigator.popUntil(context, (route) => route.isFirst);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: AppColors.gradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                    Expanded(
                      child: Text(
                        "Medical Information",
                        textAlign: TextAlign.center,
                        style:
                            AppTextStyles.heading1.copyWith(fontSize: 22),
                      ),
                    ),
                    SizedBox(width: 48),
                  ],
                ),
              ),

              SizedBox(height: 10),

              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(24),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [

                        SizedBox(height: 20),

                        Text(
                          "Medical Information",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        SizedBox(height: 16),

                        /// 🔹 HOSPITAL DROPDOWN
                        CustomDropdown(
                          hint: "Select Hospital",
                          icon: Icons.local_hospital,
                          items: Hospitals.keralHospitals,
                          value: _selectedHospital,
                          onChanged: (value) {
                            setState(() {
                              _selectedHospital = value;
                              _selectedDoctor =
                                  null; // reset doctor
                            });
                          },
                          validator: (value) =>
                              Validators.validateRequired(
                                  value, 'Hospital'),
                        ),

                        SizedBox(height: 20),

                        /// 🔹 DOCTOR DROPDOWN (LINKED TO HOSPITAL)
                        CustomDropdown(
                          hint: "Select Doctor",
                          icon: Icons.medical_services,
                          items: _selectedHospital == null
                              ? []
                              : HospitalDoctors
                                      .doctorsByHospital[
                                  _selectedHospital] ??
                                  [],
                          value: _selectedDoctor,
                          onChanged: (value) {
                            setState(() {
                              _selectedDoctor = value;
                            });
                          },
                          validator: (value) =>
                              Validators.validateRequired(
                                  value, 'Doctor'),
                        ),

                        SizedBox(height: 20),

                        CustomDropdown(
                          hint: "Blood Group",
                          icon: Icons.bloodtype,
                          items: BloodGroups.groups,
                          value: _selectedBloodGroup,
                          onChanged: (value) {
                            setState(() {
                              _selectedBloodGroup = value;
                            });
                          },
                          validator: (value) =>
                              Validators.validateRequired(
                                  value, 'Blood group'),
                        ),

                        SizedBox(height: 20),

                        CustomTextField(
                          hint: "Allergies",
                          icon: Icons.warning_amber,
                          controller: _allergiesController,
                          validator: (value) =>
                              Validators.validateRequired(
                                  value, 'Allergies'),
                        ),

                        SizedBox(height: 20),

                        CustomTextField(
                          hint:
                              "Medical History (max 200 words)",
                          icon: Icons.history,
                          controller: _medicalHistoryController,
                          maxLines: 4,
                          validator: (value) =>
                              Validators.validateTextArea(
                                  value,
                                  'Medical history',
                                  200),
                        ),

                        SizedBox(height: 20),

                        CustomTextField(
                          hint:
                              "Current Medical Status (max 200 words)",
                          icon:
                              Icons.medical_information,
                          controller:
                              _currentStatusController,
                          maxLines: 4,
                          validator: (value) =>
                              Validators.validateTextArea(
                                  value,
                                  'Current medical status',
                                  200),
                        ),

                        SizedBox(height: 30),

                        GradientButton(
                          text: "Complete Registration",
                          onPressed: _handleComplete,
                          isLoading: _isLoading,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
