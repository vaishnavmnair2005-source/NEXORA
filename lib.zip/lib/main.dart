import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(const MediTwinApp());
}

class MediTwinApp extends StatelessWidget {
  const MediTwinApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
  debugShowCheckedModeBanner: false,
  theme: ThemeData(
    primaryColor: const Color(0xFF0D47A1),
    scaffoldBackgroundColor: Colors.white,
    fontFamily: 'Roboto',
    colorScheme: ColorScheme.fromSeed(
      seedColor: const Color(0xFF1565C0),
    ),
  ),
  home: const SplashScreen(),
);

  }
}
