import 'package:flutter/material.dart';

class AppColors {
  static const primaryBlue = Color(0xFF0D47A1);
  static const secondaryBlue = Color(0xFF1565C0);
  static const lightBlue = Color(0xFFBBDEFB);
  static const white = Colors.white;
  static const grey = Color(0xFF757575);
  static const success = Color(0xFF4CAF50);
  static const warning = Color(0xFFFFA726);
  static const error = Color(0xFFF44336);
  
  static const gradientColors = [
    Color(0xFF0D47A1),
    Color(0xFF1565C0),
  ];
}

class AppTextStyles {
  static const heading1 = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.bold,
    color: Colors.white,
  );
  
  static const heading2 = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
  );
  
  static const body = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.normal,
  );
  
  static const caption = TextStyle(
    fontSize: 14,
    color: Colors.black54,
  );
}

class Hospitals {
  static const List<String> keralHospitals = [
    'KIMS Hospital, Trivandrum',
    'Medical Trust Hospital, Kochi',
    'Amrita Institute of Medical Sciences, Kochi',
    'Aster Medcity, Kochi',
    'Lakeshore Hospital, Kochi',
    'Baby Memorial Hospital, Kozhikode',
    'Malabar Institute of Medical Sciences, Kozhikode',
    'Sunrise Hospital, Kochi',
    'PRS Hospital, Trivandrum',
    'Believers Church Medical College Hospital, Thiruvalla',
  ];
}

class HospitalDoctors {

  static const Map<String, List<String>> doctorsByHospital = {

    'Aster Medcity, Kochi': [
      'Dr. Arjun Menon (Cardiologist)',
      'Dr. Meera Nair (Neurologist)',
      'Dr. Rahul Nandakumar (Pulmonologist)',
    ],

    'Amrita Hospital, Kochi': [
      'Dr. Sreeram Krishnan (Cardiologist)',
      'Dr. Anitha Varghese (Diabetologist)',
      'Dr. Vishnu Prasad (Nephrologist)',
    ],

    'KIMS Hospital, Trivandrum': [
      'Dr. Nikhil Raj (General Physician)',
      'Dr. Aparna Pillai (Endocrinologist)',
      'Dr. Sanjay Mathew (Gastroenterologist)',
    ],

    'Baby Memorial Hospital, Kozhikode': [
      'Dr. Ashwin Thomas (Cardiologist)',
      'Dr. Deepa Krishnan (Neurologist)',
      'Dr. Harish Nair (Orthopedic Surgeon)',
    ],

    'Medical Trust Hospital, Kochi': [
      'Dr. Praveen Kumar (Pulmonologist)',
      'Dr. Neethu Joseph (Dermatologist)',
      'Dr. Rakesh Menon (General Physician)',
    ],
  };
}


class BloodGroups {
  static const List<String> groups = [
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-',
    'O+',
    'O-',
  ];
}

class Genders {
  static const List<String> options = [
    'Male',
    'Female',
    'Other',
  ];
}